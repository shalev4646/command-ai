# Handoff: CommandAI — Mobile Redesign + Entry Animation

## Overview
Redesign of "CommandAI" — a Hebrew (RTL) mobile chat assistant for querying IDF General Staff orders (פקודות מטכ"ל). The app currently exists as a Python/Streamlit project (`app_soldier/`). This handoff covers three screens — Entry (role selection), Chat home, and a side drawer — plus a full-screen olive splash entry animation.

## About the Design Files
The file in this bundle (`CommandAI Final.dc.html`, with its runtime `support.js`) is a **design reference created in HTML** — a working prototype showing the intended look and behavior. It is NOT production code to copy directly. Your task is to **recreate this design in the target codebase's environment**. The existing project is Streamlit; if Streamlit is too limiting for this level of visual control (custom animations, full-screen splash, drawer), recommend and use a lightweight web frontend (e.g. React or plain HTML/CSS/JS served by the existing Python backend) — choose whatever fits the project best.

Open `CommandAI Final.dc.html` in a browser to see the live prototype (entry → chat → drawer all work).

## Fidelity
**High-fidelity.** Colors, typography, spacing, and animation timings are final. Recreate pixel-perfectly.

## Global
- Direction: `dir="rtl"`, language: Hebrew.
- Fonts (Google Fonts): **Heebo** (400/500/600/700/800) for UI text; **Suez One** for the "CommandAI" wordmark and large headings; `ui-monospace/Menlo` for classification/meta labels.
- Dark olive theme. Mobile-first, 390×844 reference viewport; content column max-width 430px centered.

## Design Tokens
Colors:
- Background: `#171A12`
- Surface (cards/buttons): `#21261A`; hover: `#2A3120`
- Primary olive: `#99A26B`; hover: `#AAB37C`
- Text: `#ECEDE6`; secondary: `rgba(236,237,230,.5–.7)`; faint: `rgba(236,237,230,.3–.35)`
- Borders: `rgba(236,237,230,.12)`; olive accent border: `rgba(153,162,107,.35)`
- Role accents: soldier olive `#99A26B`, commander tan `#B29A72` (`rgba(178,154,114,…)`), reserves blue `#8A9BC0` (`rgba(138,155,192,…)`)

Radii: cards/buttons 14px; icon tiles 12px; drawer buttons 12px; small badges 7px; input bar & role pill fully rounded (99px); send button circle.
Spacing: card padding 16px 18px; vertical gap between entry buttons 12px; screen side padding 28px (entry) / 22px (chat).

## Screens / Views

### 1. Splash (entry animation) — the chosen animation
Full-screen olive `#99A26B` overlay covering the entry screen, then slides up to reveal it.
- Content, centered column, gap 18px:
  - Chevron rank insignia: two stacked chevrons drawn with CSS borders (26×26px, 6px border-top/left, rotated 45°; second at 45% opacity, margin-top −9px), color `#171A12`. Scales in: `scale(.6)→1 + fade`, 0.6s `cubic-bezier(.2,.7,.2,1)`, delay 0.1s.
  - "CommandAI" — Suez One 34px, `#171A12`. Fades up (translateY 18px→0), 0.6s, delay 0.3s.
  - `מערכת פקודות · בלמ"ס` — monospace 11px, letter-spacing 3px, `rgba(23,26,18,.6)`. Fades up, delay 0.45s.
- The whole overlay holds for **1.15s** (tweakable), then slides up: `translateY(0)→-101%`, 0.65s `cubic-bezier(.7,0,.3,1)`.
- Splash shows once per app launch only.

### 2. Entry screen (role selection)
Background: same vertical gradient as the chat screen — `linear-gradient(180deg, #171A12 0%, #171A12 42%, #1C2114 68%, #242C18 88%, #2A3420 100%)`. Vertically centered column:
- `מערכת פקודות · בלמ"ס` — mono 11px, ls 3px, olive `#99A26B`, centered.
- Chevron insignia (22×22, 5px borders, olive; second chevron 45% opacity, margin-top −8px), margin-top 26px.
- "CommandAI" — Suez One 40px, margin-top 18px.
- `העוזר החכם לפקודות מטכ"ל` — Heebo 15px, `rgba(236,237,230,.6)`, margin-top 6px.
- Olive divider 44×2px, margin 26px auto 0.
- `בחר את סוג הכניסה שלך` — 13px/500, `rgba(236,237,230,.55)`, margin 26px 0 14px.
- **Three role buttons** (must all be kept), each: flex row gap 14px, bg `#21261A`, border 1px `rgba(236,237,230,.12)`, radius 14px, padding 16px 18px, right-aligned text; 44×44 icon tile (radius 12) with role-accent tinted bg + border; title 16px/600 + subtitle 12.5px `rgba(236,237,230,.5)`:
  1. `כניסת חיילים` / `חובה / סדיר` — olive chevron icon
  2. `כניסת מפקדים` / `קבע` — two tan bars icon
  3. `כניסת מילואים` / `מערך המילואים` — blue diamond outline icon
  - Hover: bg `#2A3120` + border tinted with role accent at .5 alpha. Active: `scale(.98)`.
- Footer: `בלמ"ס · לשימוש פנימי בלבד` — mono 10.5px, ls 2px, `rgba(236,237,230,.35)`, bottom padding 26px.

**Entry stagger (after splash lifts):** every element fades up (translateY 18px→0, 0.6s, `cubic-bezier(.2,.7,.2,1)`) in top-to-bottom order, delays ≈ splash-hold + 0.2s / 0.3s / 0.38s / 0.46s / 0.54s / 0.62s / 0.7s / 0.8s / 0.9s / 1.05s.

### 3. Chat home
- **Background:** vertical gradient (Gemini-style, in app olive colors): `linear-gradient(180deg, #171A12 0%, #171A12 42%, #1C2114 68%, #242C18 88%, #2A3420 100%)` — dark at top, warming to olive toward the composer.
- Header: **fixed/sticky** (`position:sticky; top:0; z-index:5`, bg `rgba(23,26,18,.92)`, `backdrop-filter:blur(10px)` — never scrolls away): hamburger button (40×40, radius 10, surface bg, 3 bars 16×2px) · "CommandAI" Suez One 19px · role pill on the far side: `מחובר כ־<role>` 12px/600 olive text, olive-tinted bg `rgba(153,162,107,.12)`, olive border, radius 99px, padding 5px 12px. Header bottom border `rgba(236,237,230,.1)`.
- Body **top-anchored and scrollable** (`overflow-y:auto`, padding 28px 22px 16px — suggestions sit directly under the heading, NOT bottom-anchored): `במה אפשר לעזור?` Suez One 28px; `שאלות נפוצות מהפקודות הטעונות (9)` 13px secondary; then 4 suggestion cards (same card style as entry buttons, radius 14, padding 14px 16px, 14px text, line-height 1.4):
  1. `כמה שעות שינה מגיעות לחייל ביממה לפי הפקודה?`
  2. `האם מפקד רשאי למנוע ממני יציאה לחופשה?`
  3. `מה נחשב חריגה משינה סדורה בנספח א'?`
  4. `מה התגמול הנוסף לחיילי מילואים?`
- Composer **pinned at the bottom, outside the scroll area**: pill bar (radius 99, surface bg, border `rgba(236,237,230,.15)`, padding 8px / 18px start) with placeholder `שאל על פקודה...` and a 40px circular olive send button (`↑`, text `#171A12`).
- Disclaimer under composer: `המידע אינו מחליף ייעוץ משפטי מוסמך` 10.5px faint, centered.
- Screen entrance: elements fade up staggered 0.5s each, delays 0 / .08 / .16 / .24 / .32 / .4 / .48 / .56s.

### 4. Side drawer
Opens from the **right** (RTL), width 78% (max 340px), bg `#171A12`, left border; scrim `rgba(0,0,0,.55)` fades in 0.3s; panel slides in `translateX(100%)→0`, 0.35s `cubic-bezier(.2,.7,.2,1)`. Tap scrim or `«` button to close.
Content top-to-bottom (all original buttons kept):
- Row: `מחובר כ־<role>` 12.5px secondary + collapse button `«` (34×34, radius 9, surface).
- `החלף תפקיד` button (surface card, radius 12, padding 13px 16px, 14px/600, olive `⇄` icon) → returns to entry screen (no splash replay).
- Divider.
- `פקודות טעונות` row: count badge (olive mono 12px in tinted rounded badge) + label 14.5px + chevron; tapping expands the list of 9 loaded orders (13px items with olive right border 2px):
  שעות השינה של חיילים בצה"ל · חופשות לחיילים המשרתים בשירות חובה · מניעת חופשה · הריתוק המשקי בצה"ל · תגמול נוסף לחיילי מילואים · שימוש בסמים — נוהל דיווח ומעצר · שירות קבע — חופשה ללא תשלום · הגבלת העישון במקומות ציבוריים · נוהל הטיפול בבקשות חנינה
- Divider.
- `שיחות אחרונות` section header (olive, circle icon) + empty state `אין שיחות קודמות`.
- Pinned to bottom: `+ שיחה חדשה` — full-width solid olive button, radius 12, padding 15px, text `#171A12` 15px/700 → closes drawer, resets chat.

## Interactions & Behavior
- App launch → splash (once) → entry screen staggers in.
- Choosing a role → chat screen; role name appears in header pill and drawer (`חייל` / `מפקד` / `מילואים`).
- Hamburger → drawer. `החלף תפקיד` → entry. `שיחה חדשה` → fresh chat.
- Suggestion cards / composer submit → send the question to the existing backend (`ingestion/` + `storage/json_store/*.json` order corpus). Wire to existing query logic.
- All hovers 0.15–0.2s ease; buttons press with `scale(.98)`.

## State Management
- `screen: 'entry' | 'chat'`
- `role: string` (set on entry-button click)
- `drawerOpen: boolean`, `ordersOpen: boolean` (orders list expansion)
- `splashShown: boolean` (session-scoped)
- Orders list + count come from the JSON store (currently 9 documents in `storage/json_store/`).

## Assets
No external images. All iconography is CSS-drawn (chevrons, bars, diamond, hamburger). Fonts via Google Fonts: Heebo, Suez One.

## Files
- `CommandAI Final.dc.html` — the full interactive prototype (open in a browser; requires `support.js` alongside).
- `support.js` — prototype runtime; reference only, do not ship.
